from flask import Flask, redirect, render_template, session
from flask import request

from dbms import addData, fetchData, getConnection, specificData, updateData,deleteData
app=Flask(__name__)

app.secret_key="abc"

#1st Routing
@app.route("/")
def homeFunction():
    return render_template("home.html")

@app.route("/reglink")
def regFunc():
    return render_template("register.html")

@app.route("/savelink", methods=['POST'])
def saveFunction():
    emailid=request.form['email']
    phoneno=request.form['PhoneNo']
    username=request.form['username']
    password=request.form['password']
    t=(emailid,phoneno,username,password)
    addData(t)
    print("Data saved succesfully")
    return redirect("/reglink")


@app.route("/loginlink")
def loginFunc():
    return render_template("login.html")

@app.route("/savelink2", methods=['POST'])
def save2_func():
    if request.method=="POST" and 'username' in request.form and 'password' in request.form:
        username=request.form['username']
        pasword=request.form['password']
        con=getConnection()
        cur=con.cursor()
        q1="select * from register where username=%s AND password=%s"
        cur.execute(q1,(username, pasword))
        result=cur.fetchone()
        if result:
            session['k']=True
            return redirect ("/displaylink")
        else:
            return "Incorrect username and password"

@app.route("/displaylink")
def displayFunc():
    datalist=fetchData()
    return render_template("display.html",data=datalist)
    # return render_template("display.html")

@app.route("/editlink/<int:id>")
def editFunc(id):
    datalist=specificData(id)
    return render_template("edit.html",data=datalist)

@app.route("/updatelink/<int:id>", methods=["POST"])
def updateFunc(id):
    email=request.form['email']
    phoneno=request.form['phoneno']
    username=request.form['username']
    pasword=request.form['password']
    t=(email,phoneno,username,pasword,id)
    updateData(t)
    return redirect("/displaylink")

@app.route("/deletelink/<int:id>")
def deleteFunc(id):
    deleteData(id)
    return redirect("/displaylink")

if __name__=="__main__":
    app.run(debug=True)