import pymysql as sql

def getConnection():
    conn=sql.connect(host="localhost",port=3307,user="root",database="flask_project")
    return conn

def addData(t):
    conn=getConnection()
    cur=conn.cursor()
    q1="insert into register(email,phoneno,username,password) values(%s,%s,%s,%s)"
    cur.execute(q1,t)
    conn.commit()
    conn.close()

def fetchData():
    conn=getConnection()
    cur=conn.cursor()
    q1="select * from register"
    cur.execute(q1)
    datalist=cur.fetchall()
    conn.commit()
    conn.close()
    return datalist

def specificData(id):
    conn=getConnection()
    cur=conn.cursor()
    cur.execute("select * from register where id = %s", (id,))
    datalist=cur.fetchall()
    conn.commit()
    conn.close()
    return datalist[0]

def updateData(t):
    conn=getConnection()
    cur=conn.cursor()
    q1='update register set email=%s, phoneno=%s, username=%s, password=%s where id=%s'
    cur.execute(q1,t)
    conn.commit()
    conn.close()

def deleteData(id):
    conn=getConnection()
    cur=conn.cursor()
    cur.execute('delete from register where id=%s',(id, ))
    conn.commit()
    conn.close()
